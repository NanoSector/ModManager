<?php

// Some custom code that can be inserted here. This code is a VERY BAD practice.
echo "We are sorry to see you leave; did something go wrong?";

?>