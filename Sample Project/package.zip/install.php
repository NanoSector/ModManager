<?php

// Some custom code that can be inserted here. This code is a VERY BAD practice.
echo "Thank you for installing this wonderful modification.";

?>